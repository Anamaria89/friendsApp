-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 05, 2018 at 09:12 PM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `friends_info`
--

-- --------------------------------------------------------

--
-- Table structure for table `_tb_userconection`
--

DROP TABLE IF EXISTS `_tb_userconection`;
CREATE TABLE IF NOT EXISTS `_tb_userconection` (
  `anUserId` int(11) NOT NULL,
  `anFriendId` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf16;

--
-- Dumping data for table `_tb_userconection`
--

INSERT INTO `_tb_userconection` (`anUserId`, `anFriendId`) VALUES
(1, 2),
(2, 1),
(2, 3),
(3, 2),
(3, 4),
(3, 5),
(3, 7),
(4, 3),
(5, 3),
(5, 6),
(5, 11),
(5, 10),
(1, 2),
(2, 1),
(2, 3),
(3, 2),
(3, 4),
(3, 5),
(3, 7),
(4, 3),
(5, 3),
(5, 6),
(5, 11),
(5, 10),
(5, 7),
(6, 5),
(7, 3),
(7, 5),
(7, 20),
(7, 12),
(7, 8),
(8, 7),
(9, 12),
(10, 5),
(10, 11),
(11, 5),
(11, 10),
(11, 19),
(11, 20),
(12, 7),
(12, 9),
(12, 13),
(12, 20),
(13, 12),
(13, 14),
(13, 20),
(14, 13),
(14, 15),
(15, 14),
(16, 18),
(16, 20),
(17, 18),
(17, 20),
(18, 17),
(19, 11),
(19, 20),
(20, 7),
(20, 11),
(20, 12),
(20, 13),
(20, 16),
(20, 17),
(20, 19);

-- --------------------------------------------------------

--
-- Table structure for table `_tb_users`
--

DROP TABLE IF EXISTS `_tb_users`;
CREATE TABLE IF NOT EXISTS `_tb_users` (
  `anUserId` int(11) NOT NULL,
  `acFirstName` varchar(100) DEFAULT NULL,
  `acSurname` varchar(100) DEFAULT NULL,
  `anAge` int(11) DEFAULT NULL,
  `acGender` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`anUserId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf16;

--
-- Dumping data for table `_tb_users`
--

INSERT INTO `_tb_users` (`anUserId`, `acFirstName`, `acSurname`, `anAge`, `acGender`) VALUES
(1, 'Paul', 'Crowe', 28, 'male'),
(2, 'Rob', 'Fitz', 23, 'male'),
(3, 'Ben', 'O\'Carolan', NULL, 'male'),
(4, 'Victor', '', 28, 'male'),
(5, 'Peter', 'Mac', 29, 'male'),
(6, 'John', 'Barry', 18, 'male'),
(7, 'Sarah', 'Lane', 30, 'female'),
(8, 'Susan', 'Downe', 28, 'female'),
(9, 'Jack', 'Stam', 28, 'male'),
(10, 'Amy', 'Lane', 24, 'female'),
(11, 'Sandra', 'Phelan', 28, 'female'),
(12, 'Laura', 'Murphy', 33, 'female'),
(13, 'Lisa', 'Daly', 28, 'female'),
(14, 'Mark', 'Johnson', 28, 'male'),
(15, 'Seamus', 'Crowe', 24, 'male'),
(16, 'Daren', 'Slater', 28, 'male'),
(17, 'Dara', 'Zoltan', 48, 'male'),
(18, 'Marie', 'D', 28, 'femail'),
(19, 'Catriona', 'Long', 28, 'femail'),
(20, 'Katy', 'Couch', 28, 'female');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
