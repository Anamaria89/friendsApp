<?php
	class Mdl_home extends CI_Model{
		public function __construct(){
			$this->load->database();
		}
		
		public function getUserList(){
			
			$query = "
				SELECT 
					anUserId, 
					acFirstName,
					acSurname	
				FROM _tb_users
			";
			
			$result = $this->db->query($query);
			
			foreach ($result->result() as $row) {
				$data[] = array(
					'anId' 				=> trim($row->anUserId),
					'acFName' 			=> trim($row->acFirstName),
					'acLName' 			=> trim($row->acSurname)
				);
			}	
			
			return $data;
		}
		
		public function getUserInfo($options){
			
			$query = "
				SELECT 
					anUserId, 
					acFirstName,
					acSurname,
					anAge,
					acGender		
				FROM _tb_users
				WHERE anUserId = ".$this->db->escape($options['val'])."
			";
			
			$result = $this->db->query($query);
			
			foreach ($result->result() as $row) {
				$data = array(
					'anId' 				=> trim($row->anUserId),
					'acFName' 			=> trim($row->acFirstName),
					'acLName' 			=> trim($row->acSurname),
					'anAge' 			=> trim($row->anAge),
					'acGender' 			=> trim($row->acGender)
				);
			}	
			
			return $data;
		}
		
		
		
		public function getFriends($options){
			
			$query = "
				SELECT 
					anUserId, 
					acFirstName,
					acSurname,
					anAge,
					acGender		
				FROM _tb_users
				WHERE anUserId in (select anFriendId from _tb_userconection where anUserId = ".$this->db->escape($options['val'])." )
			";
			
			$result = $this->db->query($query);
			
			foreach ($result->result() as $row) {
				$data[] = array(
					'anId' 				=> trim($row->anUserId),
					'acFName' 			=> trim($row->acFirstName),
					'acLName' 			=> trim($row->acSurname),
					'anAge' 			=> trim($row->anAge),
					'acGender' 			=> trim($row->acGender)
				);
			}	
			
			return $data;
		}
		
		public function getFriendsOfFriends($options){
			$query = "
				SELECT 
					anUserId, 
					acFirstName,
					acSurname,
					anAge,
					acGender		
				FROM _tb_users
				WHERE anUserId in (select anFriendId from _tb_userconection where anUserId in (select anFriendId from _tb_userconection where anUserId =".$this->db->escape($options['val'])." ))
			";
			
			$result = $this->db->query($query);
			
			foreach ($result->result() as $row) {
				$data[] = array(
					'anId' 				=> trim($row->anUserId),
					'acFName' 			=> trim($row->acFirstName),
					'acLName' 			=> trim($row->acSurname),
					'anAge' 			=> trim($row->anAge),
					'acGender' 			=> trim($row->acGender)
				);
			}	
			
			return $data;
		}
	}