<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	function __construct(){
		parent::__construct();

		$this->load->model('Mdl_home');

	}

	public function index(){
		
		$data['lists'] = $this->Mdl_home->getUserList();
		
		$this->load->view('home',$data);
	}
	
	
	public function getInfo(){
		foreach($this->input->post() as $key => $p) {
			$options[$key] = $p;
		}
		
		$data['friends'] = $this->Mdl_home->getFriends($options);
		$data['friendsOfFriends'] = $this->Mdl_home->getFriendsOfFriends($options);
		$data['userInfo'] = $this->Mdl_home->getUserInfo($options);
		
		echo json_encode($data);
	}
	
}
