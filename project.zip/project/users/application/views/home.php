<select name='userList'>
	<option value='-1'>Izaberite</option>
	<?php foreach($lists as $list) : ?>
		<option value='<?php echo $list['anId']?>'><?php echo $list['acFName'] .' '. $list['acLName']?></option>	
	<?php endforeach; ?>
</select>
<div class='showInfo'>
</div>
<p class='showMessage' style='color:red'></p>

<script src="http://code.jquery.com/jquery-1.10.0.min.js"></script>

<script>
	$(document).on('change', 'select[name=userList]', function(){
		val = $(this).val();
		$('.showMessage').hide();
		$('.showInfo').hide();
		if(val != '-1'){
			$.ajax({
				url:"http://localhost/users/home/getInfo",
				type: "post",
				data: {
					val: val
				},
				dataType: 'json',
				success:function(result){
					string = '';
					string = "<div>"+
						"<span><b>User information</b></span>"+
						"<span>Full name: "+result.userInfo.acFName+" "+result.userInfo.acLName+"</span>"+
						"<span>Age: "+result.userInfo.anAge+"</span>"+
						"<span>Gender: "+result.userInfo.acGender+"</span>"+
					"</div>";
					
					string += "<div>"+
								"<span><b>Friends information</b></span>";
					$.each(result.friends, function(i,d){
						string += "<span>Full name: "+d.acFName+" "+d.acLName+"</span>"+
						"<span>Age: "+d.anAge+"</span>"+
						"<span>Gender: "+d.acGender+"</span><br/>";
					});
					string += "</div>";
					
					string += "<div>"+
								"<span><b>Friends of friends information</b></span>";
					$.each(result.friendsOfFriends, function(i,d1){
						string += "<span>Full name: "+d1.acFName+" "+d1.acLName+"</span>"+
						"<span>Age: "+d1.anAge+"</span>"+
						"<span>Gender: "+d1.acGender+"</span><br/>";
					});
					string += "</div>";
					$('.showInfo').html(string);
					$('.showInfo').show();
				}			
			});
		}else{
			$('.showMessage').html('You must chose user');	
		}		
	});
</script>